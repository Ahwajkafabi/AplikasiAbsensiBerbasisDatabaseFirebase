package com.ahwajkafabi.absensiptusahamitrasejahteraalamsutera;

public class AbsensiRv {
    private String tanggal;
    private String hadir;
    private String hadirLat;
    private String hadirLong;
    private String pulang;
    private String pulangLat;
    private String pulangLong;
    private String cuti;
    private String cutiLat;
    private String cutiLong;
    private String izin;
    private String izinLat;
    private String izinLong;

    public AbsensiRv() {
    }

    public AbsensiRv(String tanggal, String hadir, String hadirLat, String hadirLong,
                     String pulang, String pulangLat, String pulangLong, String cuti,
                     String cutiLat, String cutiLong, String izin, String izinLat, String izinLong) {
        this.tanggal = tanggal;
        this.hadir = hadir;
        this.hadirLat = hadirLat;
        this.hadirLong = hadirLong;
        this.pulang = pulang;
        this.pulangLat = pulangLat;
        this.pulangLong = pulangLong;
        this.cuti = cuti;
        this.cutiLat = cutiLat;
        this.cutiLong = cutiLong;
        this.izin = izin;
        this.izinLat = izinLat;
        this.izinLong = izinLong;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getHadir() {
        return hadir;
    }

    public void setHadir(String hadir) {
        this.hadir = hadir;
    }

    public String getHadirLat() {
        return hadirLat;
    }

    public void setHadirLat(String hadirLat) {
        this.hadirLat = hadirLat;
    }

    public String getHadirLong() {
        return hadirLong;
    }

    public void setHadirLong(String hadirLong) {
        this.hadirLong = hadirLong;
    }

    public String getPulang() {
        return pulang;
    }

    public void setPulang(String pulang) {
        this.pulang = pulang;
    }

    public String getPulangLat() {
        return pulangLat;
    }

    public void setPulangLat(String pulangLat) {
        this.pulangLat = pulangLat;
    }

    public String getPulangLong() {
        return pulangLong;
    }

    public void setPulangLong(String pulangLong) {
        this.pulangLong = pulangLong;
    }

    public String getCuti() {
        return cuti;
    }

    public void setCuti(String cuti) {
        this.cuti = cuti;
    }

    public String getCutiLat() {
        return cutiLat;
    }

    public void setCutiLat(String cutiLat) {
        this.cutiLat = cutiLat;
    }

    public String getCutiLong() {
        return cutiLong;
    }

    public void setCutiLong(String cutiLong) {
        this.cutiLong = cutiLong;
    }

    public String getIzin() { return izin; }

    public void setIzin(String izin) { this.izin = izin; }

    public String getIzinLat() { return izinLat; }

    public void setIzinLat(String izinLat) { this.izinLat = izinLat; }

    public String getIzinLong() { return izinLong; }

    public void setIzinLong(String izinLong) { this.izinLong = izinLong; }
}
