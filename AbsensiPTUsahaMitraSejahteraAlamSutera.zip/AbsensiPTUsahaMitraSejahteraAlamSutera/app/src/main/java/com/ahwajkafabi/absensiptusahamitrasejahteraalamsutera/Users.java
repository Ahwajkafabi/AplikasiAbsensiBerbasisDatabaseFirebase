package com.ahwajkafabi.absensiptusahamitrasejahteraalamsutera;

import java.io.Serializable;

public class Users implements Serializable {
    private String uid;
    private String nama;
    private String nip;
    private String email;
    private String telepon;
    private String unit;
    private Boolean admin;

    public Users(String nama, String nip, String email, String telepon, String unit, Boolean admin) {
        this.nama = nama;
        this.nip = nip;
        this.email = email;
        this.telepon = telepon;
        this.unit = unit;
        this.admin = admin;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNip(String nip) { return nip; }

    public void setNip(String nip) { this.nip = nip; }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelepon() {
        return telepon;
    }

    public void setTelepon(String telepon) {
        this.telepon = telepon;
    }

    public String getUnit(String unit) { return unit; }

    public void setUnit(String unit) { this.unit = unit; }

    public Boolean getAdmin() {
        return admin;
    }

    public void setAdmin(Boolean admin) {
        this.admin = admin;
    }
}
