package com.ahwajkafabi.absensiptusahamitrasejahteraalamsutera;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

public class Assessment extends AppCompatActivity {

    WebView mWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment);

        mWebView=findViewById(R.id.myWeb);

        Intent intent=getIntent();
        String webSite=intent.getStringExtra("links");

        mWebView.setWebViewClient(new WebViewClient());
        mWebView.loadUrl(webSite);

        WebSettings webSettings=mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

    }
}
